class EmplNavbarController < ApplicationController
  def index
    @departments = Department.all
    @employees = Employee.all
  end
end
