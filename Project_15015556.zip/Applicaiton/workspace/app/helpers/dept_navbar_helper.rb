module DeptNavbarHelper
end
